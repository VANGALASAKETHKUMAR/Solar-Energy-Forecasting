# Solar Energy Forecasting

A Data Science Lab case study on solar power generation forecasting using generation and weather-sensor data from two photovoltaic plants.

## Overview

This project analyzes solar generation patterns, weather relationships, and short-term AC-power forecasting using a Random Forest regression model.

The case study covers data from **15 May 2020 to 17 June 2020** and follows a workflow of data cleaning, plant-level aggregation, weather matching, exploratory data analysis, time-based feature engineering, lag features, and chronological model evaluation.

## Objectives

- Understand the structure and quality of the solar generation and weather datasets.
- Identify daily, hourly, and monthly generation patterns for both plants.
- Study the relationship between irradiation, temperature, and AC power.
- Create time-based and lag-based forecasting features.
- Train and evaluate a Random Forest regression model using a chronological 80:20 split.
- Interpret the results in the context of renewable-energy planning and monitoring.

## Project Structure

```text
Solar-Energy-Forecasting/
├── README.md
├── requirements.txt
├── .gitignore
├── notebook/
│   └── Solar_Energy_Forecasting.ipynb
├── dataset/
│   └── README.md
├── report/
│   └── Case_Study_Report.pdf
└── results/
    └── model_verification.md
```

## Dataset

The project uses the **Solar Power Generation Data** dataset containing four files:

- `Plant_1_Generation_Data.csv`
- `Plant_1_Weather_Sensor_Data.csv`
- `Plant_2_Generation_Data.csv`
- `Plant_2_Weather_Sensor_Data.csv`

Download the original dataset from Kaggle:

https://www.kaggle.com/datasets/anikannal/solar-power-generation-data

Place the four CSV files inside the `dataset/` folder before running the notebook.

The notebook also supports running from the same directory as the CSV files.

## Technologies

- Python
- Pandas
- NumPy
- Matplotlib
- Seaborn
- Scikit-learn
- Jupyter Notebook / Google Colab

## Analysis Workflow

1. Load the four source datasets.
2. Convert timestamps to datetime format.
3. Check missing values and duplicates.
4. Aggregate inverter-level generation by timestamp and plant.
5. Aggregate weather observations by timestamp and plant.
6. Merge generation and weather data.
7. Create calendar features.
8. Perform exploratory data analysis.
9. Create 15-minute, 1-hour, and 1-day lag features.
10. Split the data chronologically into 80% training and 20% testing data.
11. Train a Random Forest Regressor.
12. Evaluate using MAE, RMSE, and R².

## Dataset Verification

The completed preprocessing pipeline reproduces the case-study report's **6,416 timestamp-level analytical observations** after plant-level aggregation and weather matching.

The reproduced plant-level AC-power totals are:

| Plant | AC Power Total |
|---|---:|
| Plant 1 | 21,167,150 |
| Plant 2 | 16,334,026.21 |

## Model Verification

The report states the following Random Forest results:

| Metric | Reported result | Reproduced notebook result |
|---|---:|---:|
| MAE | 467.41 | 496.35 |
| RMSE | 1208.99 | 1277.63 |
| R² | 0.9693 | 0.9658 |

The preprocessing results match the report, but the model metrics do not reproduce exactly from the methodological details available in the report. The repository therefore reports the actual executed notebook results rather than changing the experiment solely to force a numerical match.

## How to Run

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Download the dataset

Download the four CSV files from the Kaggle dataset and place them in:

```text
dataset/
```

### 3. Open the notebook

Open:

```text
notebook/Solar_Energy_Forecasting.ipynb
```

You can run it with Jupyter Notebook, JupyterLab, or upload it to Google Colab.

## Case Study Report

The submitted case-study report is available in:

```text
report/Case_Study_Report.pdf
```

## SDG Connection

The case study is aligned with:

- **SDG 7 – Affordable and Clean Energy**
- **SDG 13 – Climate Action**

## Team

The case-study report contains the complete team information and author details.

## Future Work

The report identifies possible extensions including additional meteorological variables, longer forecasting horizons, alternative models such as Gradient Boosting or recurrent neural networks, uncertainty intervals, and comparison against simple forecasting baselines.
